# Reusable skills

A skill is a reusable set of instructions for an AI assistant: what to do, which steps to follow, and what a useful result looks like. Skills save you from rewriting the same directions and help keep a workflow consistent. Review the result each time; a skill does not guarantee accuracy or run an application by itself.

Choose a skill in the alphabetical list, copy its Markdown, and use the project prompt to turn its workflow into a vibe-coded solution. The collection has 26 skills. Concept sketches suggest possible interfaces; the 14 new hero illustrations evoke their workflows. Neither is a finished app.

Each entry also includes **Use with an AI agent**: an agent-ready file, a skill setup prompt, and a prompt for immediate use. The [agent directions](../AGENT_GUIDE.md) cover the 26 skills plus the four featured guides; [download all 30 agent skills](../downloads/vcc-agent-skills.zip) for local skill setup.

**Preparing a book for listening?** [Audiobook Maker](skills.html#audiobook-maker) adapts **Lance Eaton's Book to Audio Edition** workflow from [AI Audiobooks: An Update](https://aiedusimplified.substack.com/p/ai-audiobooks-an-update) and his [MIT-licensed repository](https://github.com/leaton79/book-to-audiobook). The VCC adaptation preserves prose, maps relocated notes, and checks for missing content. Its [free local audio path](../skills/audiobook-maker/references/free-local-audio.md) explains how to turn the checked text into chapter audio or an M4B without a paid narration service. [Download the complete skill ZIP](../downloads/audiobook-maker.zip), or use [PageSpindle](https://mguhlin.github.io/pagespindle/), the companion app with desktop downloads and local browser AI/narration.

**Building a Go application?** [Go App Builder](skills.html#go-app-builder) covers Windows, macOS, Linux, Android, and the browser. Its shared-core and platform-adapter workflow includes compatibility tables, offline installation and operation, secure file access, accessible interfaces, the four VCC checks, and verification of published artifacts. [Download its complete skill ZIP](../downloads/go-app-builder.zip), including the project prompt and detailed references. The main skill remains useful on its own; fetch or attach the platform references for deeper work.

## From instructions to a working tool

1. Download the skill's `SKILL.md` into a folder named for the skill, or copy its full text into your assistant. File placement and automatic discovery depend on the assistant; explicitly ask it to read the file.
2. Add VCC's [design](design.html), [education privacy](education.html), and [security](security.html) instruction files to the project. Follow [Start here](start.html) for setup.
3. Copy the project prompt and adapt the audience, subject, and constraints. Ask your coding assistant to read the skill and the relevant instruction files before building. For stabilization and recovery, also use [Vibe-Code Rescue](rescue.html).
4. Try the resulting tool with invented examples. Check the learning task, keyboard use, narrow-screen layout, reset, and export before sharing.

Most starter projects use guided forms and prompts without requiring a live AI service. They do not automatically judge claims, cite sources, or assess students. Adding AI later requires a separate review of data flows, provider settings, and server-side credentials.

## Collection and reuse

The first seven skills were supplied by Miguel Guhlin for VCC. SIFT credits Mike Caulfield's framework. Compare Options and Source Integrity are self-contained adaptations of Miguel Guhlin's CC0 skills in [mguhlin/creations](https://github.com/mguhlin/creations/tree/main/architect/skills/packages). The 14 creator adaptations add critical thinking, ethical decisions, district planning, policy work, workshop and proposal design, instructional coaching, storytelling, learning calendars, authorized video archiving, and careful text/file cleanup. See [sources and changes](../skills/SOURCES.md) and [credits and reuse](../CREDITS.md).

[Download all 26 skills, project prompts, and concept images](../downloads/reusable-skills.zip). The [complete VCC download](../downloads/vcc-complete.zip) also includes this collection.

Browse and copy locally after downloading. Copy buttons work when the browser grants clipboard access; otherwise select the text and use your device's copy command. No accounts, uploaded documents, or AI API calls are used by this library.
