const { chromium }=require(process.env.VCC_PLAYWRIGHT||'@playwright/test');
const assert=require('node:assert/strict');
(async()=>{
const browser=await chromium.launch({headless:true,executablePath:process.env.VCC_CHROME||undefined,args:['--no-sandbox']});
const context=await browser.newContext({viewport:{width:1440,height:1000},permissions:['clipboard-read','clipboard-write']});
const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
const base=process.env.VCC_URL||'http://127.0.0.1:4186/';
await page.goto(base,{waitUntil:'networkidle'});
if(process.env.VCC_SCREENSHOTS==='1')await page.screenshot({path:'/tmp/vcc-desktop.png',fullPage:true});
assert.ok((await page.locator('.hero img').getAttribute('src')).endsWith('/four-checks.webp'));
await page.getByRole('link',{name:'Read the cartoon as text',exact:true}).click();assert.ok(page.url().includes('/guides/before-sharing.html#the-cartoon-in-text'));assert.ok(await page.getByRole('heading',{name:'The cartoon in text',exact:true}).isVisible());await page.goto(base);
assert.equal(await page.locator('.foundation img').count(),4);
for(const img of await page.locator('.foundation img').all()){
 await img.scrollIntoViewIfNeeded();
 assert.ok(await img.evaluate(el=>el.complete&&el.naturalWidth===1600&&el.naturalHeight===900));
}
assert.equal(await page.getByRole('heading',{name:'What is VCC?',exact:true}).count(),0);
await page.locator('footer').getByRole('link',{name:'About',exact:true}).click();
assert.ok(page.url().endsWith('/guides/about.html'));assert.equal(await page.locator('h1').textContent(),'About VCC');assert.ok((await page.locator('main').textContent()).includes('a growing collection of guidance, reusable instructions'));
await page.goto(base);
for(const route of ['design','security','education','rescue']){await page.locator('.foundation[href="guides/'+route+'.html"]').click();assert.ok(page.url().endsWith('/guides/'+route+'.html'));assert.ok(await page.locator('.guide-explainer').isVisible());await page.goto(base);}
assert.equal(await page.locator('[data-resource],#resource-search,#result-count').count(),0);
assert.equal(await page.locator('#start,#before-sharing,.checklist').count(),0);assert.equal(await page.locator('#ai-agent-instructions [data-copy]').count(),1);
assert.ok(await page.evaluate(()=>Boolean(document.querySelector('#library').compareDocumentPosition(document.querySelector('#download'))&Node.DOCUMENT_POSITION_FOLLOWING)));
assert.ok(await page.evaluate(()=>Boolean(document.querySelector('#download').compareDocumentPosition(document.querySelector('#tools'))&Node.DOCUMENT_POSITION_FOLLOWING)));
assert.equal(await page.getByRole('heading',{name:'From the blog',exact:true}).count(),0);
assert.equal(await page.getByText('What did not make the recommended shelf?',{exact:true}).count(),0);
assert.deepEqual(await page.locator('#repo-list h3').allTextContents(),['unslop','UI UX Pro Max','Design Bites','axe-core','Playwright','Gitleaks','ZAP','Accessibility Insights for Web']);
const supplement=page.locator('.supplement-nav');
await supplement.locator('summary').focus();await page.keyboard.press('Enter');assert.ok(await supplement.evaluate(el=>el.open));
await page.keyboard.press('Tab');assert.equal(await page.locator(':focus').textContent(),'Start here');
await page.keyboard.press('Escape');assert.equal(await supplement.evaluate(el=>el.open),false);assert.equal(await page.locator(':focus').textContent(),'Supplementals');
await supplement.locator('summary').click();await page.locator('h1').click();assert.equal(await supplement.evaluate(el=>el.open),false);
await supplement.locator('summary').click();await supplement.getByRole('link',{name:'Resource library',exact:true}).click();
assert.ok(page.url().endsWith('/guides/library.html'));assert.equal(await page.locator('[data-resource]:visible').count(),8);
await page.locator('#resource-search').fill('privacy');assert.ok(await page.locator('[data-resource]:visible').count()>0);
await page.locator('#resource-search').fill('zzzznomatch');assert.ok(await page.locator('#no-results').isVisible());
await page.locator('#clear-search').click();await page.locator('#resource-category').selectOption('security');assert.equal(await page.locator('[data-resource]:visible').count(),1);
await page.locator('#clear-search').click();assert.equal(await page.locator('[data-resource]:visible').count(),8);
await page.locator('#resource-category').selectOption('rescue');assert.equal(await page.locator('[data-resource]:visible').count(),1);await page.locator('#clear-search').click();
await supplement.locator('summary').click();await supplement.getByRole('link',{name:'Start here',exact:true}).click();
assert.ok(page.url().endsWith('/guides/start.html'));assert.ok(await page.getByRole('heading',{name:'What is PROJECT_BRIEF.md?',exact:true}).isVisible());
assert.equal(await page.locator('.supplement-links [aria-current="page"]').textContent(),'Start here');
await page.locator('[data-copy]').click();await page.waitForFunction(()=>document.querySelector('.copy-status').textContent.length>0);assert.equal(await page.locator('.copy-status').textContent(),'Prompt copied');
assert.ok((await page.evaluate(()=>navigator.clipboard.readText())).includes('PROJECT_BRIEF.md'));
assert.ok((await page.evaluate(()=>navigator.clipboard.readText())).includes('If the brief is missing'));
await page.locator('.supplement-nav summary').click();await page.getByRole('link',{name:'Before sharing with a class',exact:true}).click();assert.ok(page.url().endsWith('/guides/before-sharing.html'));
assert.equal(await page.locator('#the-cartoon-in-text + ol > li').count(),4);
assert.ok(await page.locator('a[download][href$="/four-checks.png"]').isVisible());
await page.locator('.checklist input').first().check();assert.ok((await page.locator('#check-summary').textContent()).startsWith('1 of 6'));
await page.locator('#reset-checks').click();assert.equal(await page.locator('.checklist input:checked').count(),0);
await page.reload();assert.equal(await page.locator('.checklist input:checked').count(),0);
await page.locator('.supplement-nav summary').click();await page.getByRole('link',{name:'Publishing walkthroughs',exact:true}).click();assert.ok(page.url().endsWith('/guides/publishing.html'));assert.equal(await page.locator('.cartoon img').count(),2);assert.ok(await page.getByRole('heading',{name:'The GitHub cartoon in text',exact:true}).isVisible());
for(const name of ['github-pages','netlify','three-essential-checks']){const original=await context.request.get(base+'assets/cartoons/'+name+'.png');assert.equal(original.status(),200);assert.ok((await original.body()).length>1000000);}
await page.goto(base+'#start');await page.waitForURL('**/guides/start.html');
await page.goto(base+'#before-sharing');await page.waitForURL('**/guides/before-sharing.html');
await page.goto(base+'#what');await page.waitForURL('**/guides/about.html');
await page.goto(base);
await page.keyboard.press('Tab');assert.equal(await page.locator(':focus').textContent(),'Skip to content');await page.keyboard.press('Enter');assert.equal(await page.evaluate(()=>location.hash),'#main');
await page.evaluate(require('node:fs').readFileSync(process.env.VCC_AXE||require.resolve('axe-core/axe.min.js'),'utf8')); 
let axe=await page.evaluate(()=>axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','wcag22aa']}}));
console.log('Home axe violations',JSON.stringify(axe.violations.map(x=>({id:x.id,impact:x.impact,nodes:x.nodes.map(n=>n.target)}))));assert.equal(axe.violations.length,0);
for(const route of ['design','security','education','project-brief','launch','prompts','resource-vetting','start','before-sharing','blog','library','about','publishing','skills','rescue']){
 const response=await page.goto(base+'guides/'+route+'.html');assert.equal(response.status(),200);assert.equal(await page.locator('h1').count(),1);
 await page.evaluate(require('node:fs').readFileSync(process.env.VCC_AXE||require.resolve('axe-core/axe.min.js'),'utf8')); 
 axe=await page.evaluate(()=>axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa','wcag22aa']}}));
 console.log(route+' axe violations',JSON.stringify(axe.violations.map(x=>({id:x.id,nodes:x.nodes.map(n=>n.target)}))));assert.equal(axe.violations.length,0);
}
await page.setViewportSize({width:390,height:844});await page.goto(base);if(process.env.VCC_SCREENSHOTS==='1')await page.screenshot({path:'/tmp/vcc-mobile.png',fullPage:true});
assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
await page.locator('.supplement-nav summary').click();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.keyboard.press('Escape');
await page.goto(base+'guides/library.html');
await page.locator('#resource-category').selectOption('design');assert.equal(await page.locator('[data-resource]:visible').count(),1);
for(const route of ['', 'guides/security.html','guides/education.html','guides/resource-vetting.html','guides/start.html','guides/before-sharing.html','guides/blog.html','guides/library.html','guides/about.html','guides/publishing.html','guides/skills.html','guides/rescue.html']){
 await page.goto(base+route);await page.setViewportSize({width:320,height:800});await page.waitForFunction(()=>innerWidth===320);await page.evaluate(()=>new Promise(requestAnimationFrame));assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),route+' reflow');
 await page.locator('.supplement-nav summary').click();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),route+' open menu reflow');await page.keyboard.press('Escape');
}
await page.setViewportSize({width:1280,height:900});await page.goto(base);await page.evaluate(()=>document.body.style.fontSize='34px');assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
await page.emulateMedia({reducedMotion:'reduce'});assert.equal(await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),true);
await require('./skills-browser-check.cjs')({page,context,base});
await page.goto(base+'guides/security.html');
assert.ok(await page.getByRole('heading',{name:'Before repairing an existing app',exact:true}).count());
await page.locator('.note').getByRole('link',{name:'Vibe-Code Rescue',exact:true}).click();
assert.ok(page.url().endsWith('/guides/rescue.html'));
await page.getByRole('button',{name:'Copy rescue audit prompt',exact:true}).focus();await page.keyboard.press('Enter');
await page.waitForFunction(()=>document.querySelector('#rescue-audit-prompt').parentElement.querySelector('.copy-status').textContent==='Prompt copied');
assert.ok((await page.evaluate(()=>navigator.clipboard.readText())).includes('Use AUDIT mode'));
await page.locator('.note').getByRole('link',{name:'SecureVCC',exact:true}).click();assert.ok(page.url().endsWith('/guides/security.html'));
const rescueDownload=await context.request.get(base+'rescue/VIBE_CODE_RESCUE.md');assert.equal(rescueDownload.status(),200);assert.ok((await rescueDownload.text()).includes('# Vibe-Code Rescue'));
await page.goto(base+'guides/design.html#modern-web-guidance');
assert.ok(await page.getByRole('heading',{name:'Modern Web Guidance',exact:true}).isVisible());
await page.getByRole('button',{name:'Copy modernization prompt',exact:true}).click();
await page.waitForFunction(()=>document.querySelector('#modern-web-prompt').parentElement.querySelector('.copy-status').textContent==='Modernization prompt copied');
assert.ok((await page.evaluate(()=>navigator.clipboard.readText())).includes('verify compatibility'));
await require('./agent-browser-check.cjs')({page,context,base});
const download=await context.request.get(base+'downloads/vcc-complete.zip');assert.equal(download.status(),200);assert.ok((await download.body()).length>1000000);
assert.deepEqual(errors,[]);console.log('PASS: cartoon hero/text link, publishing navigation, original PNG downloads, About footer, four guide cards, rescue/security links, rescue audit copy/download, and download order, library search/filter/reset, curated shelf, keyboard dismissal, prompt copy, classroom reminders, keyboard skip, 16-page axe scan, mobile/open-menu reflow, text resizing, reduced motion, ZIP, no runtime errors');
await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
