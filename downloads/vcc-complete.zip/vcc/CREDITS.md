# Credits and reuse

VCC is created by Miguel Guhlin. Original VCC website code is offered under the MIT license in `LICENSE`. Original VCC educational prose, templates, WEB_DESIGN.md, and EDU_COMPLIANCE.md are offered under CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Attribute Miguel Guhlin and link to VCC when sharing adaptations. Third-party material retains its own terms.

## SecureVCC

SecureVCC adapts supplied security prompts and Cloudflare’s security-audit-skill. Its full MIT notice remains inside `securevcc/securevcc.md`. The original archive and license are preserved in `securevcc/sources/`. See `securevcc/SOURCES.md` for detailed provenance. The readable VCC security guide is generated from that Markdown; its license notice remains intact.

## Design refinement

The VCC design refinement follows unslop by Damir Sokolovsky (https://github.com/heydamir/unslop), licensed CC BY 4.0. Credit is retained here and in the site footer. This is a process attribution; upstream unslop scripts and reference images are not redistributed in this bundle.

## Images

The workbench hero was generated and revised to blue and silver using the built-in OpenAI image generation tool for this project. The image is an illustration, not a screenshot of a working application. The Helpful GitHubs toolkit illustration was also created with built-in OpenAI image generation and optimized for this site; its prompt is in `assets/github-toolkit-prompt.txt`. The user supplied the AI Design Playbook for Education Websites and Education Compliance Guide visuals; VCC includes optimized WebP copies. No third-party brand or government certification is implied by those visuals.

## Supplied cartoons

Miguel Guhlin supplied the GitHub Pages, Netlify, and Three Essential Checks cartoons. Original PNG copies are preserved in `assets/cartoons/`, alongside full-resolution WebP versions optimized for page display. VCC includes text alternatives and links to the originals. Product names and logos within the supplied artwork retain their owners' rights; their appearance does not imply endorsement.

## Linked resources

GitHub resources are linked references, not bundled or automatically installed. Each upstream license, dependency notice, asset right, and model license applies separately. A repository license does not grant rights to copied brand identities or every linked example. See RESOURCE_REVIEW.md for license signals and limitations.

## Reusable skills

The seven user-supplied skills and VCC project prompts are educational prose by Miguel Guhlin under CC BY 4.0. SIFT credits Mike Caulfield's framework. Compare Options and Source Integrity adapt Miguel Guhlin's CC0-1.0 skill files in mguhlin/creations and retain CC0-1.0; each adaptation links to its source. The original vector concept sketches were drawn in code for VCC and follow its CC BY 4.0 educational visual terms. See [skill sources and changes](skills/SOURCES.md). No upstream executable code or image assets are bundled with the adaptations.
